package ru.netology.IlyaRomanov.exception;

public class OperationRuntimeException extends RuntimeException {
}
