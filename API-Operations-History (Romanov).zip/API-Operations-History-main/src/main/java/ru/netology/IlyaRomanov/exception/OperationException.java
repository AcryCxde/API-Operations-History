package ru.netology.IlyaRomanov.exception;

public abstract class OperationException extends Exception {

    public abstract String getMessage();
}
