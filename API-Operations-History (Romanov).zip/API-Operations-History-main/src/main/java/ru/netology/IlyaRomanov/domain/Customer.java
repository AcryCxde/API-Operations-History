package ru.netology.IlyaRomanov.domain;

import lombok.Data;

@Data
public class Customer {
    private final int id;
    private final String name;
}