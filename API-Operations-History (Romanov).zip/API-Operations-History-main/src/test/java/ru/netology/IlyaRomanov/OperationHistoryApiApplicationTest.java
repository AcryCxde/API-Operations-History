package ru.netology.IlyaRomanov;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OperationHistoryApiApplicationTest {

    @Test
    void contextLoad() {
    }
}
